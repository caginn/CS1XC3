/**
 * @file course.c
 * @author Cagin Yildirim (yildiric@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
/**
 * @brief Enrolling a given student into a given course
 * 
 * @param course a course which you want to add student into
 * @param student a student which you wanto to add into course
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));    // This line of code allocate space for size of 1 student
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); // This line of code allocate space if there is more than 1 student in the course
  }
  course->students[course->total_students - 1] = *student; // This line of code assigning student to the list
}

/**
 * @brief Printing course information; name, code, total students
 * 
 * @param course a course which we want to get info about
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Returning the highest average student in course
 * 
 * @param course a course which we want to see highest average student in
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Checking each student if they pass the course and keep tracking total passing count
 * 
 * @param course a course which we want to check
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++; // checking if the student pass the course and updating the count
  
  passing = calloc(count, sizeof(Student)); // We need enough room to fit students in, this is the list for it

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}